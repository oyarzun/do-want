INSERT INTO `events` (`eventid`, `userid`, `description`, `eventdate`, `recurring`)
VALUES
	(1,NULL,'Christmas','2000-12-25',1);
