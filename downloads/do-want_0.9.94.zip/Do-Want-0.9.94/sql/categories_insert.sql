INSERT INTO `categories` (`categoryid`, `category`)
VALUES
	(1,'Books'),
	(2,'Music'),
	(3,'Video Games'),
	(4,'Clothing'),
	(5,'Movies/DVD'),
	(6,'Gift Certificates'),
	(7,'Hobbies'),
	(8,'Household'),
	(9,'Electronics'),
	(10,'Ornaments/Figurines'),
	(11,'Automotive'),
	(12,'Toys'),
	(13,'Jewellery'),
	(14,'Computer'),
	(15,'Games'),
	(16,'Tools');
