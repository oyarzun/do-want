CREATE TABLE `families` (
  `familyid` int(11) NOT NULL AUTO_INCREMENT,
  `familyname` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`familyid`)
);